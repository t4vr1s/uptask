exports.vardump = (objeto) => JSON.stringify(objeto, null, 2);
